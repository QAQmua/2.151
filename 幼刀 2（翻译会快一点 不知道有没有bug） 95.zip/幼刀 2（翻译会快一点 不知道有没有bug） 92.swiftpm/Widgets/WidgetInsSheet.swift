// 📄 完整替换文件：Widgets/WidgetInsSheet.swift
import SwiftUI
import PhotosUI

// MARK: - ins 发布页专属编辑面板
struct EditInsWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var widgetManager = InsPostWidgetManager.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    @State private var selectedCategoryTab: Int = 0
    @State private var selectedAvatarItem: PhotosPickerItem? = nil
    @State private var selectedPostItem: PhotosPickerItem? = nil
    
    private var triggerKey: String { "\(selectedCategoryTab)" }
    
    private let textColors = ["#000000", "#FFFFFF", "#3C3C43", "#8E8E93", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    private let bgPresets = ["#FFFFFF", "#EDEDF2", "#1C1C1E", "#FDE2E4", "#E2ECE9", "#FFF1C5", "#D0E1FD", "#E8DFF5"]
    private let borderPresets = ["#000000", "#8E8E93", "#FFFFFF", "#007AFF", "#FF2D55", "#5856D6", "#E5E5EA"]
    
    private let coordinateIcons: [(id: String, name: String)] = [
        ("classic_pin", "标准倒水滴"),
        ("mappin.fill", "实心图钉"),
        ("mappin", "空心图钉"),
        ("mappin.circle.fill", "圆底水滴"),
        ("mappin.and.ellipse", "阴影水滴"),
        ("location.fill", "定位实心"),
        ("location", "定位空心"),
        ("location.circle.fill", "准星圆环")
    ]
    
    private let presetRegions = [
        "中国 · 北京", "中国 · 上海", "中国 · 广州", "中国 · 深圳",
        "中国 · 成都", "中国 · 杭州", "中国 · 香港", "中国 · 台北",
        "Tokyo, Japan", "Paris, France", "New York, USA", "London, UK"
    ]
    
    private let mentionPresets = [
        "#007AFF", "#3897F0", "#5856D6", "#FF2D55", "#FF9500", "#34C759", "#AF52DE", "#00C7BE"
    ]
    
    private let gridColumns = Array(repeating: GridItem(.flexible(), spacing: 8), count: 4)
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            VStack(spacing: 0) {
                if widgetManager.isPinPreviewToTop {
                    pinnedHeaderView(s: s)
                        .overlay(alignment: .bottom) {
                            ZStack {
                                Rectangle().fill(.ultraThinMaterial)
                                LinearGradient(
                                    colors: [Color(UIColor.systemGroupedBackground), Color(UIColor.systemGroupedBackground).opacity(0)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            }
                            .frame(height: 18)
                            .offset(y: 18)
                            .mask(
                                LinearGradient(
                                    stops: [.init(color: .black, location: 0.0), .init(color: .black.opacity(0.6), location: 0.4), .init(color: .clear, location: 1.0)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .allowsHitTesting(false)
                        }
                        .zIndex(10)
                }
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !widgetManager.isPinPreviewToTop {
                            pinnedHeaderView(s: s)
                                .padding(.top, 10)
                        }
                        
                        if selectedCategoryTab == 0 {
                            styleCategorySection()
                                .padding(.top, widgetManager.isPinPreviewToTop ? 14 : 0)
                        } else {
                            contentCategorySection()
                                .padding(.top, widgetManager.isPinPreviewToTop ? 14 : 0)
                        }
                    }
                    .padding(.bottom, 36)
                }
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("ins 发布页".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                            widgetManager.isPinPreviewToTop.toggle()
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: widgetManager.isPinPreviewToTop ? "pin.fill" : "pin.slash")
                                .font(.system(size: 13, weight: .semibold))
                            Text(widgetManager.isPinPreviewToTop ? "取消置顶".tr : "置顶预览".tr)
                                .font(.system(size: 13))
                        }
                        .foregroundColor(widgetManager.isPinPreviewToTop ? appearance.accentTextColor : .secondary)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        widgetManager.objectWillChange.send()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .foregroundColor(appearance.accentTextColor)
                }
            }
            .task(id: selectedAvatarItem) {
                if let item = selectedAvatarItem, let data = try? await item.loadTransferable(type: Data.self) {
                    await MainActor.run {
                        withAnimation(.easeInOut(duration: 0.25)) { widgetManager.avatarImageData = data }
                        widgetManager.objectWillChange.send()
                        selectedAvatarItem = nil
                        UINotificationFeedbackGenerator().notificationOccurred(.success)
                    }
                }
            }
            .task(id: selectedPostItem) {
                if let item = selectedPostItem, let data = try? await item.loadTransferable(type: Data.self) {
                    await MainActor.run {
                        withAnimation(.easeInOut(duration: 0.25)) { widgetManager.postImageData = data }
                        widgetManager.objectWillChange.send()
                        selectedPostItem = nil
                        UINotificationFeedbackGenerator().notificationOccurred(.success)
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
    
    // MARK: - 预览与分段器
    private func pinnedHeaderView(s: CGFloat) -> some View {
        VStack(spacing: 12) {
            InsPostWidget4x4View(
                manager: widgetManager,
                showDashedBorder: true,
                onDeletePostImage: { withAnimation { widgetManager.postImageData = nil } }
            )
            .frame(height: 330 * s)
            .shadow(color: Color.black.opacity(0.06), radius: 8, y: 4)
            .padding(.horizontal, 16 * s)
            
            Picker("", selection: $selectedCategoryTab.animation(.spring(response: 0.35, dampingFraction: 0.82))) {
                Text("样式".tr).tag(0)
                Text("内容".tr).tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 24)
        }
        .padding(.top, 10)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity)
        .background(Color(UIColor.systemGroupedBackground))
    }
    
    // MARK: - 样式分类
    private func styleCategorySection() -> some View {
        VStack(spacing: 16) {
            // 背景与描边
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("背景与外边框".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    Toggle(isOn: $widgetManager.isTransparentBackground) {
                        Label("背景透明".tr, systemImage: "circle.lefthalf.filled").font(.system(size: 15, weight: appearance.systemFontWeight))
                    }
                    .tint(appearance.toggleTintColor)
                }
                
                if !widgetManager.isTransparentBackground {
                    Divider()
                    DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                        WidgetColorPaletteRow(title: "背景底色".tr, selectedHex: widgetManager.backgroundColorHex, presets: bgPresets, currentColor: widgetManager.backgroundColor, onSelectHex: { widgetManager.backgroundColorHex = $0 }, onPickColor: { widgetManager.backgroundColorHex = $0.toHex() })
                    }
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 3, triggerKey: triggerKey) {
                    Toggle(isOn: $widgetManager.hasBorder) {
                        Label("启用外边框描边".tr, systemImage: "square.dashed").font(.system(size: 15, weight: appearance.systemFontWeight))
                    }
                    .tint(appearance.toggleTintColor)
                    
                    if widgetManager.hasBorder {
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text("描边粗细".tr).font(.system(size: 14, weight: appearance.systemFontWeight))
                                Spacer()
                                Text(String(format: "%.1f pt", widgetManager.borderWidth)).font(.caption).foregroundColor(.secondary)
                            }
                            Slider(value: $widgetManager.borderWidth, in: 0.1...6.0, step: 0.1)
                                .tint(appearance.sliderTrackColor)
                        }
                        .padding(.top, 4)
                        
                        WidgetColorPaletteRow(title: "描边颜色".tr, selectedHex: widgetManager.borderColorHex, presets: borderPresets, currentColor: widgetManager.borderColor, onSelectHex: { widgetManager.borderColorHex = $0 }, onPickColor: { widgetManager.borderColorHex = $0.toHex() })
                    }
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 头像尺寸与微调
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("头像与右上角图标微调".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text("头像大小".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                            Spacer()
                            Text("\(Int(widgetManager.avatarSize)) pt").font(.caption).foregroundColor(.secondary)
                        }
                        Slider(value: $widgetManager.avatarSize, in: 28...60, step: 1)
                            .tint(appearance.sliderTrackColor)
                    }
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 10) {
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text("纸飞机图标大小".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                Spacer()
                                Text(String(format: "%.1f pt", widgetManager.sendIconSize)).font(.caption).foregroundColor(.secondary)
                            }
                            Slider(value: $widgetManager.sendIconSize, in: 8.0...35.0, step: 0.5)
                                .tint(appearance.sliderTrackColor)
                        }
                        
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text("左右横向微调".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                Spacer()
                                Text(String(format: "%+.1f pt", widgetManager.sendIconOffsetX)).font(.caption).foregroundColor(.secondary)
                            }
                            Slider(value: $widgetManager.sendIconOffsetX, in: -30.0...30.0, step: 0.5)
                                .tint(appearance.sliderTrackColor)
                        }
                        
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Text("上下纵向微调".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                Spacer()
                                Text(String(format: "%+.1f pt", widgetManager.sendIconOffsetY)).font(.caption).foregroundColor(.secondary)
                            }
                            Slider(value: $widgetManager.sendIconOffsetY, in: -30.0...30.0, step: 0.5)
                                .tint(appearance.sliderTrackColor)
                        }
                        
                        WidgetColorPaletteRow(title: "纸飞机图标颜色".tr, selectedHex: widgetManager.sendIconColorHex, presets: textColors, currentColor: widgetManager.sendIconColor, onSelectHex: { widgetManager.sendIconColorHex = $0 }, onPickColor: { widgetManager.sendIconColorHex = $0.toHex() })
                    }
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 地区坐标图标与 @ 艾特高亮
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("定位图标与高亮".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    Toggle(isOn: $widgetManager.showLocationIcon) {
                        Label("显示地区坐标图标".tr, systemImage: "mappin.and.ellipse").font(.system(size: 15, weight: appearance.systemFontWeight))
                    }
                    .tint(appearance.toggleTintColor)
                    
                    if widgetManager.showLocationIcon {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("选择坐标图标样式".tr).font(.system(size: 14, weight: appearance.systemFontWeight))
                            LazyVGrid(columns: gridColumns, spacing: 8) {
                                ForEach(coordinateIcons, id: \.id) { item in
                                    Button(action: {
                                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                        widgetManager.selectedLocationIcon = item.id
                                    }) {
                                        VStack(spacing: 4) {
                                            ZStack {
                                                RoundedRectangle(cornerRadius: 10, style: .continuous)
                                                    .fill(widgetManager.selectedLocationIcon == item.id ? Color.accentColor.opacity(0.18) : Color(UIColor.tertiarySystemGroupedBackground))
                                                    .overlay(
                                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                                            .stroke(widgetManager.selectedLocationIcon == item.id ? Color.accentColor : Color.clear, lineWidth: 1.5)
                                                    )
                                                    .frame(height: 38)
                                                
                                                InsLocationIconView(iconName: item.id, size: 16, color: widgetManager.selectedLocationIcon == item.id ? .accentColor : .primary)
                                            }
                                            Text(item.name).font(.system(size: 10)).foregroundColor(widgetManager.selectedLocationIcon == item.id ? .accentColor : .secondary).lineLimit(1)
                                        }
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                        .padding(.top, 4)
                        
                        WidgetColorPaletteRow(title: "坐标图标颜色".tr, selectedHex: widgetManager.locationIconColorHex, presets: textColors, currentColor: widgetManager.locationIconColor, onSelectHex: { widgetManager.locationIconColorHex = $0 }, onPickColor: { widgetManager.locationIconColorHex = $0.toHex() })
                    }
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    WidgetColorPaletteRow(title: "艾特（@）高亮文字颜色".tr, selectedHex: widgetManager.mentionColorHex, presets: mentionPresets, currentColor: widgetManager.mentionColor, onSelectHex: { widgetManager.mentionColorHex = $0 }, onPickColor: { widgetManager.mentionColorHex = $0.toHex() })
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 文本排版细项
            VStack(spacing: 14) {
                WidgetTextSectionEditor(sectionTitle: "左上角文字排版".tr, placeholder: "如：取消".tr, text: $widgetManager.headerCancelText, size: $widgetManager.headerCancelSize, minSize: 10, maxSize: 20, selectedWeightName: $widgetManager.headerCancelWeightName, selectedHex: widgetManager.headerCancelColorHex, currentColor: widgetManager.headerCancelColor, onSelectHex: { widgetManager.headerCancelColorHex = $0 }, onPickColor: { widgetManager.headerCancelColorHex = $0.toHex() })
                WidgetTextSectionEditor(sectionTitle: "顶部主标题排版".tr, placeholder: "如：发布动态".tr, text: $widgetManager.headerTitle, size: $widgetManager.headerTitleSize, minSize: 11, maxSize: 22, selectedWeightName: $widgetManager.headerTitleWeightName, selectedHex: widgetManager.headerTitleColorHex, currentColor: widgetManager.headerTitleColor, onSelectHex: { widgetManager.headerTitleColorHex = $0 }, onPickColor: { widgetManager.headerTitleColorHex = $0.toHex() })
                WidgetTextSectionEditor(sectionTitle: "右上角文字排版".tr, placeholder: "如：send".tr, text: $widgetManager.headerSendText, size: $widgetManager.headerSendSize, minSize: 10, maxSize: 20, selectedWeightName: $widgetManager.headerSendWeightName, selectedHex: widgetManager.headerSendColorHex, currentColor: widgetManager.headerSendColor, onSelectHex: { widgetManager.headerSendColorHex = $0 }, onPickColor: { widgetManager.headerSendColorHex = $0.toHex() })
                WidgetTextSectionEditor(sectionTitle: "昵称排版".tr, placeholder: "如：用户1011".tr, text: $widgetManager.authorName, size: $widgetManager.authorNameSize, minSize: 11, maxSize: 24, selectedWeightName: $widgetManager.authorNameWeightName, selectedHex: widgetManager.authorNameColorHex, currentColor: widgetManager.authorNameColor, onSelectHex: { widgetManager.authorNameColorHex = $0 }, onPickColor: { widgetManager.authorNameColorHex = $0.toHex() })
                WidgetTextSectionEditor(sectionTitle: "地区文案/签名排版".tr, placeholder: "输入任何你想展示的地区，如：中国 · 上海 或 @好友".tr, text: $widgetManager.authorSubText, size: $widgetManager.authorSubTextSize, minSize: 8, maxSize: 18, selectedWeightName: $widgetManager.authorSubTextWeightName, selectedHex: widgetManager.authorSubTextColorHex, currentColor: widgetManager.authorSubTextColor, onSelectHex: { widgetManager.authorSubTextColorHex = $0 }, onPickColor: { widgetManager.authorSubTextColorHex = $0.toHex() })
                WidgetTextSectionEditor(sectionTitle: "发帖正文排版".tr, placeholder: "如：此刻在想什么... @好友".tr, text: $widgetManager.contentText, size: $widgetManager.contentTextSize, minSize: 10, maxSize: 22, selectedWeightName: $widgetManager.contentTextWeightName, selectedHex: widgetManager.contentTextColorHex, currentColor: widgetManager.contentTextColor, onSelectHex: { widgetManager.contentTextColorHex = $0 }, onPickColor: { widgetManager.contentTextColorHex = $0.toHex() })
            }
        }
    }
    
    // MARK: - 内容分类
    private func contentCategorySection() -> some View {
        VStack(spacing: 16) {
            // 照片管理
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("头像与发帖主图".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                // 头像选图
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    HStack(spacing: 12) {
                        ZStack {
                            if let data = widgetManager.avatarImageData, let uiImg = UIImage(data: data) {
                                Image(uiImage: uiImg).resizable().scaledToFill()
                            } else {
                                Color(UIColor.tertiarySystemFill)
                                Image(systemName: "person.fill").font(.system(size: 18)).foregroundColor(.secondary)
                            }
                        }
                        .frame(width: 52, height: 52)
                        .clipShape(Circle())
                        
                        PhotosPicker(selection: $selectedAvatarItem, matching: .images, photoLibrary: .shared()) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(widgetManager.avatarImageData == nil ? "选取头像图片".tr : "更换头像图片".tr)
                                    .font(.system(size: 15, weight: .medium)).foregroundColor(.primary)
                                Text("点击从相册选择专属头像".tr).font(.system(size: 12)).foregroundColor(.secondary)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        
                        if widgetManager.avatarImageData != nil {
                            Button(action: {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                withAnimation { widgetManager.avatarImageData = nil }
                            }) {
                                Image(systemName: "xmark.circle.fill").font(.system(size: 20)).foregroundColor(Color(UIColor.tertiaryLabel))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 12).padding(.vertical, 10)
                    .background(Color(UIColor.tertiarySystemFill).opacity(0.55)).cornerRadius(14)
                }
                
                Divider()
                
                // 发帖主图选图
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    HStack(spacing: 12) {
                        ZStack {
                            if let data = widgetManager.postImageData, let uiImg = UIImage(data: data) {
                                Image(uiImage: uiImg).resizable().scaledToFill()
                            } else {
                                Color(UIColor.tertiarySystemFill)
                                Image(systemName: "photo.badge.plus").font(.system(size: 18)).foregroundColor(.secondary)
                            }
                        }
                        .frame(width: 52, height: 52)
                        .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
                        
                        PhotosPicker(selection: $selectedPostItem, matching: .images, photoLibrary: .shared()) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(widgetManager.postImageData == nil ? "选取发帖主图".tr : "更换发帖主图".tr)
                                    .font(.system(size: 15, weight: .medium)).foregroundColor(.primary)
                                Text("点击添加主卡片配图".tr).font(.system(size: 12)).foregroundColor(.secondary)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        
                        if widgetManager.postImageData != nil {
                            Button(action: {
                                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                withAnimation { widgetManager.postImageData = nil }
                            }) {
                                Image(systemName: "xmark.circle.fill").font(.system(size: 20)).foregroundColor(Color(UIColor.tertiaryLabel))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 12).padding(.vertical, 10)
                    .background(Color(UIColor.tertiarySystemFill).opacity(0.55)).cornerRadius(14)
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 文本与地区输入
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("动态文案与署名".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("昵称".tr).font(.caption2).foregroundColor(.secondary)
                        TextField("如：用户1011".tr, text: $widgetManager.authorName)
                            .font(.subheadline).padding(10).background(Color(UIColor.tertiarySystemFill)).cornerRadius(10)
                    }
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("地区文案 / 自定义地点".tr).font(.caption2).foregroundColor(.secondary)
                            Spacer()
                            Menu {
                                ForEach(presetRegions, id: \.self) { loc in
                                    Button(loc) {
                                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                        widgetManager.authorSubText = loc
                                    }
                                }
                            } label: {
                                HStack(spacing: 4) {
                                    Text("预设地区".tr).font(.system(size: 12))
                                    Image(systemName: "chevron.up.chevron.down").font(.caption2)
                                }
                                .foregroundColor(.accentColor)
                            }
                        }
                        TextField("输入展示地区，如：中国 · 上海".tr, text: $widgetManager.authorSubText)
                            .font(.subheadline).padding(10).background(Color(UIColor.tertiarySystemFill)).cornerRadius(10)
                    }
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 3, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("发帖正文 (支持输入 @ 自动变色)".tr).font(.caption2).foregroundColor(.secondary)
                        TextField("如：此刻在想什么... @好友".tr, text: $widgetManager.contentText, axis: .vertical)
                            .lineLimit(2...5)
                            .font(.subheadline).padding(10).background(Color(UIColor.tertiarySystemFill)).cornerRadius(10)
                    }
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
        }
    }
}
