// 📄 文件路径：信息/MessagesChatDetailView.swift
import SwiftUI
import PhotosUI
import AudioToolbox

// MARK: - 可选铃声音效列表
struct ChatSoundOption: Identifiable, Hashable {
    let id: Int
    let name: String
}

let chatSendSoundOptions: [ChatSoundOption] = [
    ChatSoundOption(id: 1004, name: "经典飞跃 (Swoosh - 默认)"),
    ChatSoundOption(id: 1057, name: "轻柔弹泡 (Pop)"),
    ChatSoundOption(id: 1000, name: "清脆铃音 (Ding)"),
    ChatSoundOption(id: 1001, name: "疾风邮件 (Whoosh)"),
    ChatSoundOption(id: 1016, name: "灵动鸟鸣 (Tweet)"),
    ChatSoundOption(id: 1025, name: "空灵钟琴 (Chime)"),
    ChatSoundOption(id: 0,    name: "静音 (无声音)")
]

let chatReceiveSoundOptions: [ChatSoundOption] = [
    ChatSoundOption(id: 1005, name: "经典三音 (Tri-tone - 默认)"),
    ChatSoundOption(id: 1003, name: "电子短音 (Note)"),
    ChatSoundOption(id: 1002, name: "玻璃轻敲 (Glass)"),
    ChatSoundOption(id: 1000, name: "清脆叮咚 (Ding)"),
    ChatSoundOption(id: 1057, name: "轻柔弹泡 (Pop)"),
    ChatSoundOption(id: 1016, name: "灵动鸟鸣 (Tweet)"),
    ChatSoundOption(id: 1025, name: "空灵钟琴 (Chime)"),
    ChatSoundOption(id: 0,    name: "静音 (无声音)")
]

// MARK: - Color 颜色转换辅助扩展
extension Color {
    func toHexString() -> String {
        let uic = UIColor(self)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        guard uic.getRed(&r, green: &g, blue: &b, alpha: &a) else { return "#007AFF" }
        return String(format: "#%02X%02X%02X", Int(r * 255), Int(g * 255), Int(b * 255))
    }
}

@MainActor
struct MessagesChatDetailView: View {
    let conversationID: String
    @ObservedObject var viewModel = MessagesViewModel.shared
    @ObservedObject var netEngine = MessagesNetworkEngine.shared
    @Environment(\.colorScheme) private var colorScheme
    
    // 🌟 按会话持久化存储的音效、双向外观与字体大小设置
    @AppStorage private var selectedSendSoundID: Int
    @AppStorage private var selectedReceiveSoundID: Int
    @AppStorage private var customBubbleColorHex: String
    @AppStorage private var customTextColorHex: String
    @AppStorage private var customPeerBubbleColorHex: String
    @AppStorage private var customPeerTextColorHex: String
    @AppStorage private var customSendButtonColorHex: String
    @AppStorage private var bgImageID: String
    @AppStorage private var chatFontSize: Double
    
    @State private var inputText: String = ""
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @State private var avatarPhotoItem: PhotosPickerItem? = nil
    @State private var replyingToMessage: IMMessageItem? = nil
    @State private var showSendEffectSheet: Bool = false
    @State private var showContactInfoSheet: Bool = false
    @State private var revealedInvisibleIDs: Set<String> = []
    @FocusState private var isInputFocused: Bool
    
    // 🌟 多选删除与批量管理状态
    @State private var isSelectionMode: Bool = false
    @State private var selectedMessageIDs: Set<String> = []
    @State private var showClearAllConfirm: Bool = false
    
    init(conversationID: String) {
        self.conversationID = conversationID
        self._selectedSendSoundID = AppStorage(wrappedValue: 1004, "chat_send_sound_\(conversationID)")
        self._selectedReceiveSoundID = AppStorage(wrappedValue: 1005, "chat_receive_sound_\(conversationID)")
        self._customBubbleColorHex = AppStorage(wrappedValue: "", "chat_bubble_color_\(conversationID)")
        self._customTextColorHex = AppStorage(wrappedValue: "", "chat_text_color_\(conversationID)")
        self._customPeerBubbleColorHex = AppStorage(wrappedValue: "", "chat_peer_bubble_color_\(conversationID)")
        self._customPeerTextColorHex = AppStorage(wrappedValue: "", "chat_peer_text_color_\(conversationID)")
        self._customSendButtonColorHex = AppStorage(wrappedValue: "", "chat_send_btn_color_\(conversationID)")
        self._bgImageID = AppStorage(wrappedValue: "", "chat_bg_image_\(conversationID)")
        self._chatFontSize = AppStorage(wrappedValue: 16.5, "chat_font_size_\(conversationID)")
    }
    
    private var conversation: IMConversation? {
        viewModel.conversations.first(where: { $0.id == conversationID })
    }
    
    private var isPeerTyping: Bool {
        guard let conv = conversation else { return false }
        let norm = MessagesNetworkEngine.normalizeID(conv.peerID)
        return viewModel.peerTypingMap[norm] ?? false
    }
    
    var body: some View {
        ZStack {
            // 🌟 1. 暗黑模式底色设为 #010001（浅色模式保持原生白）
            (colorScheme == .dark ? Color(hex: "#010001") : Color(UIColor.systemBackground))
                .ignoresSafeArea()
            
            // 🌟 2. 聊天背景壁纸
            if !bgImageID.isEmpty,
               let data = LocalImageStore.shared.load(id: bgImageID),
               let uiImg = ImageBitmapCache.shared.image(from: data) {
                Image(uiImage: uiImg)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .ignoresSafeArea()
                    .overlay(Color.black.opacity(colorScheme == .dark ? 0.35 : 0.08))
            }
            
            // 🌟 3. 聊天消息主体
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 0) {
                        if let conv = conversation {
                            VStack(spacing: 3) {
                                Text(conv.isSMSChannel ? "iMessage信息" : "iMessage信息")
                                    .font(.caption2.weight(.medium))
                                
                                HStack(spacing: 3) {
                                    Image(systemName: "lock.fill")
                                        .font(.caption2)
                                        .imageScale(.small)
                                    Text("已加密")
                                        .font(.caption2.weight(.medium))
                                }
                            }
                            .foregroundStyle(.secondary)
                            .padding(.top, 60)
                            .padding(.bottom, 12)
                            
                            // 消息气泡流
                            let msgs = conv.messages
                            ForEach(Array(msgs.enumerated()), id: \.element.id) { index, msg in
                                let showTime = index == 0 || msg.timestamp.timeIntervalSince(msgs[index - 1].timestamp) > 3600
                                
                                let hasTimeGapWithNext = (index + 1 < msgs.count) && (msgs[index + 1].timestamp.timeIntervalSince(msg.timestamp) > 3600)
                                let hasTimeGapWithPrev = (index > 0) && (msg.timestamp.timeIntervalSince(msgs[index - 1].timestamp) > 3600)
                                
                                let isNextSame = (index + 1 < msgs.count) && (msgs[index + 1].isFromMe == msg.isFromMe) && !hasTimeGapWithNext
                                let isPrevSame = (index > 0) && (msgs[index - 1].isFromMe == msg.isFromMe) && !hasTimeGapWithPrev
                                let isLastFromMe = (index == msgs.lastIndex(where: { $0.isFromMe }))
                                
                                NativeMessageBubbleRow(
                                    message: msg,
                                    isPrevSameSender: isPrevSame,
                                    isNextSameSender: isNextSame,
                                    isLastSentMessage: isLastFromMe,
                                    showTimeHeader: showTime,
                                    isInvisibleRevealed: revealedInvisibleIDs.contains(msg.id),
                                    fontSize: CGFloat(chatFontSize),
                                    isSelectionMode: isSelectionMode,
                                    isSelected: selectedMessageIDs.contains(msg.id),
                                    customBubbleColor: customBubbleColorHex.isEmpty ? nil : Color(hex: customBubbleColorHex),
                                    customTextColor: customTextColorHex.isEmpty ? nil : Color(hex: customTextColorHex),
                                    customPeerBubbleColor: customPeerBubbleColorHex.isEmpty ? nil : Color(hex: customPeerBubbleColorHex),
                                    customPeerTextColor: customPeerTextColorHex.isEmpty ? nil : Color(hex: customPeerTextColorHex),
                                    onRevealInvisible: {
                                        withAnimation { _ = revealedInvisibleIDs.insert(msg.id) }
                                    },
                                    onToggleSelect: {
                                        toggleMessageSelection(msg.id)
                                    },
                                    onStartSelectMode: {
                                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                                            isSelectionMode = true
                                            selectedMessageIDs.insert(msg.id)
                                        }
                                    },
                                    onTapback: { symbol in
                                        viewModel.sendTapback(in: conv.id, messageID: msg.id, symbol: symbol)
                                    },
                                    onReply: {
                                        withAnimation {
                                            replyingToMessage = msg
                                            isInputFocused = true
                                        }
                                    },
                                    onDelete: {
                                        if let cIdx = viewModel.conversations.firstIndex(where: { $0.id == conv.id }) {
                                            withAnimation {
                                                viewModel.conversations[cIdx].messages.removeAll(where: { $0.id == msg.id })
                                                viewModel.saveConversations()
                                            }
                                        }
                                    }
                                )
                                .id(msg.id)
                            }
                        }
                        
                        // 打字气泡平滑过渡
                        if isPeerTyping {
                            HStack {
                                NativeTypingIndicatorBubble()
                                Spacer()
                            }
                            .padding(.horizontal, 16)
                            .padding(.top, 4)
                            .id("typing_indicator")
                            .transition(
                                .asymmetric(
                                    insertion: .scale(scale: 0.5, anchor: .bottomLeading).combined(with: .opacity),
                                    removal: .scale(scale: 0.75, anchor: .bottomLeading).combined(with: .opacity)
                                )
                            )
                        }
                        
                        Color.clear.frame(height: 10).id("bottom_anchor")
                    }
                    .animation(.spring(response: 0.38, dampingFraction: 0.78), value: isPeerTyping)
                }
                .scrollDismissesKeyboard(.interactively)
                .modifier(IOS26NativeBottomSafeAreaBar {
                    if isSelectionMode {
                        nativeBottomSelectionBar
                    } else {
                        nativeBottomInputBar
                    }
                })
                .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)) { _ in
                    withAnimation(.spring(response: 0.38, dampingFraction: 0.82)) {
                        proxy.scrollTo("bottom_anchor", anchor: .bottom)
                    }
                }
                .onChange(of: isPeerTyping) { _, isTyping in
                    if isTyping {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
                            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                                proxy.scrollTo("typing_indicator", anchor: .bottom)
                            }
                        }
                    }
                }
                .onChange(of: conversation?.messages.count) { oldCount, newCount in
                    viewModel.markConversationAsRead(conversationID)
                    guard let old = oldCount, let new = newCount, new > old else { return }
                    
                    if let lastMsg = conversation?.messages.last, !lastMsg.isFromMe {
                        let receiveSound = selectedReceiveSoundID
                        if receiveSound != 0 {
                            DispatchQueue.global(qos: .userInteractive).async {
                                AudioServicesPlaySystemSound(SystemSoundID(receiveSound))
                            }
                        }
                        
                        ChatNotificationManager.shared.scheduleMessageNotification(
                            senderName: conversation?.name ?? "新信息",
                            messageText: lastMsg.text.isEmpty ? "[图片]" : lastMsg.text,
                            conversationID: conversationID,
                            delay: 1.0
                        )
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                        withAnimation(.spring(response: 0.38, dampingFraction: 0.82)) {
                            proxy.scrollTo("bottom_anchor", anchor: .bottom)
                        }
                    }
                }
                .onAppear {
                    viewModel.markConversationAsRead(conversationID)
                    ChatNotificationManager.shared.requestAuthorization()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                        proxy.scrollTo("bottom_anchor", anchor: .bottom)
                    }
                }
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if isSelectionMode {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完成") {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.82)) {
                            isSelectionMode = false
                            selectedMessageIDs.removeAll()
                        }
                    }
                    .font(.system(size: 17, weight: .bold))
                }
            } else {
                ToolbarItem(placement: .principal) {
                    principalHeaderItem
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showContactInfoSheet = true
                    } label: {
                        Image(systemName: "video")
                    }
                }
            }
        }
        .confirmationDialog("使用特效发送", isPresented: $showSendEffectSheet, titleVisibility: .visible) {
            Button("震撼 (Slam)") { commitSend(effect: "slam") }
            Button("响亮 (Loud)") { commitSend(effect: "loud") }
            Button("轻柔 (Gentle)") { commitSend(effect: "gentle") }
            Button("隐形墨水 (刮开可见)") { commitSend(effect: "invisible") }
            Button("取消", role: .cancel) {}
        }
        .confirmationDialog("确定要清空该会话所有聊天记录吗？", isPresented: $showClearAllConfirm, titleVisibility: .visible) {
            Button("全部删除", role: .destructive) {
                clearAllMessages()
            }
            Button("取消", role: .cancel) {}
        }
        .sheet(isPresented: $showContactInfoSheet) {
            if let conv = conversation {
                NativeContactDetailSheet(
                    conversation: conv,
                    avatarPhotoItem: $avatarPhotoItem,
                    selectedSendSoundID: $selectedSendSoundID,
                    selectedReceiveSoundID: $selectedReceiveSoundID,
                    customBubbleColorHex: $customBubbleColorHex,
                    customTextColorHex: $customTextColorHex,
                    customPeerBubbleColorHex: $customPeerBubbleColorHex,
                    customPeerTextColorHex: $customPeerTextColorHex,
                    customSendButtonColorHex: $customSendButtonColorHex,
                    bgImageID: $bgImageID,
                    chatFontSize: $chatFontSize,
                    onClearAll: {
                        clearAllMessages()
                    }
                )
                .presentationDetents([.medium, .large])
            }
        }
        .task(id: selectedPhotoItem) {
            if let item = selectedPhotoItem,
               let data = try? await item.loadTransferable(type: Data.self) {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) {
                    viewModel.sendMessage(in: conversationID, text: "", imageData: data, replyTo: replyingToMessage)
                }
                replyingToMessage = nil
                selectedPhotoItem = nil
            }
        }
        .task(id: avatarPhotoItem) {
            if let item = avatarPhotoItem,
               let data = try? await item.loadTransferable(type: Data.self),
               let idx = viewModel.conversations.firstIndex(where: { $0.id == conversationID }) {
                viewModel.conversations[idx].avatarImageID = LocalImageStore.shared.save(data: data)
                viewModel.saveConversations()
                avatarPhotoItem = nil
            }
        }
        .onChange(of: inputText) { _, newValue in
            guard let conv = conversation, !conv.isAIContact && !conv.isSMSChannel else { return }
            viewModel.sendTypingStatus(to: conv.peerID, isTyping: !newValue.isEmpty)
        }
    }
    
    // MARK: - 顶栏：锁定水平中轴对齐
    @ViewBuilder
    private var principalHeaderItem: some View {
        if let conv = conversation {
            Button {
                showContactInfoSheet = true
            } label: {
                let arrowSize: CGFloat = 13.3
                
                let namePill = HStack(spacing: 5.5) {
                    Text(conv.name)
                        .font(.system(size: 17, weight: .bold))
                        .fontWeight(.bold)
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                        .truncationMode(.tail)
                    
                    Canvas { context, size in
                        let s = size.height / 11.0
                        var path = Path()
                        path.move(to: CGPoint(x: 1.2 * s, y: 1.5 * s))
                        path.addLine(to: CGPoint(x: 3.0 * s, y: 5.5 * s))
                        path.addLine(to: CGPoint(x: 1.2 * s, y: 9.5 * s))
                        context.stroke(
                            path,
                            with: .color(.secondary.opacity(0.62)),
                            style: StrokeStyle(lineWidth: 2.1 * s, lineCap: .round, lineJoin: .round)
                        )
                    }
                    .frame(width: arrowSize * (4.5 / 11.0), height: arrowSize)
                }
                    .frame(height: 18)
                    .padding(.leading, 12.3)
                    .padding(.trailing, 9.7)
                    .padding(.vertical, 7.5)
                    .frame(maxWidth: 180)
                
                let avatar = NativeContactAvatarView(
                    name: conv.name,
                    colorHex: conv.avatarColorHex,
                    imageID: conv.avatarImageID,
                    size: 58
                )
                    .shadow(color: .black.opacity(0.18), radius: 6, x: 0, y: 3)
                
                ZStack(alignment: Alignment(horizontal: .center, vertical: .top)) {
                    namePill
                        .background(.regularMaterial, in: Capsule())
                        .padding(.top, 53)
                    
                    avatar
                }
                .frame(maxWidth: 200)
                .offset(y: 18)
            }
            .buttonStyle(.plain)
        }
    }
    
    // MARK: - 🌟 原生多选底部工具栏
    @ViewBuilder
    private var nativeBottomSelectionBar: some View {
        HStack {
            Button(role: .destructive) {
                showClearAllConfirm = true
            } label: {
                Text("全部删除")
                    .font(.system(size: 16, weight: .regular))
                    .foregroundStyle(.red)
            }
            
            Spacer()
            
            Text(selectedMessageIDs.isEmpty ? "轻点勾选信息" : "已选择 \(selectedMessageIDs.count) 条")
                .font(.system(size: 14))
                .foregroundStyle(.secondary)
            
            Spacer()
            
            Button {
                deleteSelectedMessages()
            } label: {
                Image(systemName: "trash")
                    .font(.system(size: 19))
                    .foregroundStyle(selectedMessageIDs.isEmpty ? Color.secondary.opacity(0.4) : Color.red)
            }
            .disabled(selectedMessageIDs.isEmpty)
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 12)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .padding(.horizontal, 16)
        .padding(.vertical, 6)
        .transition(.move(edge: .bottom).combined(with: .opacity))
    }
    
    // MARK: - 原生底部输入栏
    @ViewBuilder
    private var nativeBottomInputBar: some View {
        let isTypingActive = isInputFocused || !inputText.isEmpty
        
        let plusMenu = Menu {
            PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                Label("照片", systemImage: "photo.on.rectangle")
            }
            Button {
                showSendEffectSheet = true
            } label: {
                Label("发送特效", systemImage: "sparkles")
            }
            Button {
                showContactInfoSheet = true
            } label: {
                Label("更换对方头像与备注", systemImage: "person.crop.circle")
            }
        } label: {
            Image(systemName: "plus")
                .font(.system(size: 19, weight: .semibold))
                .foregroundStyle(Color(UIColor.label))
                .frame(width: 38, height: 38)
        }
        
        let sendBtnColor: Color = {
            if !customSendButtonColorHex.isEmpty {
                return Color(hex: customSendButtonColorHex)
            } else if !customBubbleColorHex.isEmpty {
                return Color(hex: customBubbleColorHex)
            } else {
                return conversation?.isSMSChannel == true ? Color(hex: "#34C759") : Color(hex: "#007AFF")
            }
        }()
        
        let textFieldCapsule = HStack(alignment: .bottom, spacing: 8) {
            ZStack(alignment: .leading) {
                if inputText.isEmpty {
                    Text(conversation?.isSMSChannel == true ? "iMessage信息" : "iMessage信息")
                        .font(.system(size: 14.5, weight: .regular))
                        .foregroundStyle(.secondary.opacity(0.72))
                        .padding(.vertical, 8)
                        .padding(.leading, 14)
                        .allowsHitTesting(false)
                }
                
                TextField("", text: $inputText, axis: .vertical)
                    .font(.system(size: 16.5, weight: .regular))
                    .lineLimit(1...5)
                    .focused($isInputFocused)
                    .padding(.vertical, 8)
                    .padding(.leading, 14)
            }
            
            let canSend = !inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            if canSend {
                Button {
                    commitSend(effect: nil)
                } label: {
                    ZStack {
                        Capsule()
                            .fill(sendBtnColor)
                            .frame(width: 36, height: 27)
                        
                        Text("↑")
                            .font(.system(size: 19, weight: .heavy))
                            .foregroundStyle(.white)
                            .offset(y: 0)
                    }
                }
                .simultaneousGesture(
                    LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                        UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
                        showSendEffectSheet = true
                    }
                )
                .padding(.trailing, 7)
                .padding(.bottom, 4.7)
            } else {
                Image(systemName: "mic")
                    .font(.system(size: 16))
                    .foregroundStyle(.secondary)
                    .padding(.trailing, 14)
                    .padding(.bottom, 9)
            }
        }
            .frame(minHeight: 40)
        
        HStack(alignment: .bottom, spacing: 10) {
            plusMenu
                .background(.ultraThinMaterial, in: Circle())
            textFieldCapsule
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
        .padding(.horizontal, isTypingActive ? 20 : 25)
        .padding(.vertical, 6)
        .animation(.spring(response: 0.35, dampingFraction: 0.82), value: isTypingActive)
    }
    
    // MARK: - 辅助操作：多选与清空
    private func toggleMessageSelection(_ id: String) {
        withAnimation(.easeInOut(duration: 0.18)) {
            if selectedMessageIDs.contains(id) {
                selectedMessageIDs.remove(id)
            } else {
                selectedMessageIDs.insert(id)
            }
        }
    }
    
    private func deleteSelectedMessages() {
        guard let conv = conversation, !selectedMessageIDs.isEmpty else { return }
        if let cIdx = viewModel.conversations.firstIndex(where: { $0.id == conv.id }) {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                viewModel.conversations[cIdx].messages.removeAll(where: { selectedMessageIDs.contains($0.id) })
                viewModel.saveConversations()
                selectedMessageIDs.removeAll()
                isSelectionMode = false
            }
        }
    }
    
    private func clearAllMessages() {
        guard let conv = conversation else { return }
        if let cIdx = viewModel.conversations.firstIndex(where: { $0.id == conv.id }) {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                viewModel.conversations[cIdx].messages.removeAll()
                viewModel.saveConversations()
                selectedMessageIDs.removeAll()
                isSelectionMode = false
            }
        }
    }
    
    private func commitSend(effect: String?) {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        
        let soundToPlay = selectedSendSoundID
        if soundToPlay != 0 {
            DispatchQueue.global(qos: .userInteractive).async {
                AudioServicesPlaySystemSound(SystemSoundID(soundToPlay))
            }
        }
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        
        withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) {
            viewModel.sendMessage(
                in: conversationID,
                text: trimmed,
                imageData: nil,
                replyTo: replyingToMessage,
                effect: effect
            )
        }
        
        inputText = ""
        replyingToMessage = nil
    }
}

// MARK: - 底部安全区修饰器 (支持 iOS 17 / iOS 18 原生)
struct IOS26NativeBottomSafeAreaBar<BarContent: View>: ViewModifier {
    @ViewBuilder let barContent: () -> BarContent
    
    func body(content: Content) -> some View {
        content
            .safeAreaInset(edge: .bottom) {
                barContent()
            }
    }
}

// MARK: - 🌟 网图单例加载器
class RemoteTailImageLoader: ObservableObject {
    static let shared = RemoteTailImageLoader()
    @Published var tailImage: UIImage? = nil
    
    private init() {
        guard let url = URL(string: "https://i.postimg.cc/k5pv6GGG/wu-biao-ti672-20260207151704.png") else { return }
        URLSession.shared.dataTask(with: url) { data, _, _ in
            if let data = data, let img = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.tailImage = img
                }
            }
        }.resume()
    }
}

// MARK: - 🌟 核心：原生矩形 + URL 贴纸无缝拼合背景
struct CompositeBubbleBackground: View {
    let isFromMe: Bool
    let hasTail: Bool
    let tintColor: Color
    
    @StateObject private var loader = RemoteTailImageLoader.shared
    
    var body: some View {
        ZStack(alignment: isFromMe ? .bottomTrailing : .bottomLeading) {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(tintColor)
            
            if hasTail {
                if let uiImage = loader.tailImage {
                    Image(uiImage: uiImage)
                        .renderingMode(.template)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 21, height: 21)
                        .foregroundStyle(tintColor)
                        .scaleEffect(x: isFromMe ? 1 : -1, y: 1)
                        .offset(x: isFromMe ? -3.6 : 3.6, y: 9.6)
                }
            }
        }
        .compositingGroup()
    }
}

// MARK: - 消息气泡单行视图
struct NativeMessageBubbleRow: View {
    let message: IMMessageItem
    let isPrevSameSender: Bool
    let isNextSameSender: Bool
    let isLastSentMessage: Bool
    let showTimeHeader: Bool
    let isInvisibleRevealed: Bool
    var fontSize: CGFloat = 16.5
    var isSelectionMode: Bool = false
    var isSelected: Bool = false
    var customBubbleColor: Color? = nil
    var customTextColor: Color? = nil
    var customPeerBubbleColor: Color? = nil
    var customPeerTextColor: Color? = nil
    let onRevealInvisible: () -> Void
    let onToggleSelect: () -> Void
    let onStartSelectMode: () -> Void
    let onTapback: (String?) -> Void
    let onReply: () -> Void
    let onDelete: () -> Void
    
    @Environment(\.colorScheme) private var colorScheme
    
    private let tapbackItems: [(symbol: String, label: String)] = [
        ("heart.fill", "爱心"),
        ("hand.thumbsup.fill", "赞"),
        ("hand.thumbsdown.fill", "踩"),
        ("face.smiling.inverse", "哈哈"),
        ("exclamationmark.2", "强调"),
        ("questionmark", "疑问")
    ]
    
    private var timeString: String {
        let f = DateFormatter()
        f.dateFormat = "HH:mm"
        return f.string(from: message.timestamp)
    }
    
    private var headerTimeString: String {
        let f = DateFormatter()
        if Calendar.current.isDateInToday(message.timestamp) {
            f.dateFormat = "今天 HH:mm"
        } else if Calendar.current.isDateInYesterday(message.timestamp) {
            f.dateFormat = "昨天 HH:mm"
        } else {
            f.dateFormat = "M月d日 HH:mm"
        }
        return f.string(from: message.timestamp)
    }
    
    var body: some View {
        VStack(alignment: message.isFromMe ? .trailing : .leading, spacing: 3) {
            
            if showTimeHeader {
                Text(headerTimeString)
                    .font(.caption2.weight(.medium))
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.top, 14)
                    .padding(.bottom, 6)
            }
            
            if let preview = message.replyPreview {
                Text("回复：\(preview)")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .padding(.horizontal, 20)
            }
            
            HStack(alignment: .bottom, spacing: 0) {
                if isSelectionMode {
                    Button(action: onToggleSelect) {
                        Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                            .font(.system(size: 22))
                            .foregroundStyle(isSelected ? Color(hex: "#007AFF") : Color.secondary.opacity(0.45))
                            .padding(.trailing, 10)
                    }
                    .buttonStyle(.plain)
                    .transition(.move(edge: .leading).combined(with: .opacity))
                }
                
                if message.isFromMe { Spacer(minLength: 80) }
                
                VStack(alignment: message.isFromMe ? .trailing : .leading, spacing: 4) {
                    ZStack(alignment: message.isFromMe ? .topLeading : .topTrailing) {
                        bubbleContentBody
                            .frame(maxWidth: 520, alignment: message.isFromMe ? .trailing : .leading)
                            .contextMenu {
                                if !isSelectionMode {
                                    Section {
                                        ForEach(tapbackItems, id: \.symbol) { item in
                                            Button {
                                                let next = (message.tapback == item.symbol) ? nil : item.symbol
                                                onTapback(next)
                                            } label: {
                                                Label(item.label, systemImage: item.symbol)
                                            }
                                        }
                                    }
                                    Section {
                                        Button(action: onReply) {
                                            Label("回复", systemImage: "arrowshape.turn.up.left")
                                        }
                                        if !message.text.isEmpty {
                                            Button {
                                                UIPasteboard.general.string = message.text
                                            } label: {
                                                Label("拷贝", systemImage: "doc.on.doc")
                                            }
                                        }
                                        Button(action: onStartSelectMode) {
                                            Label("更多...", systemImage: "ellipsis.circle")
                                        }
                                        Button(role: .destructive, action: onDelete) {
                                            Label("删除", systemImage: "trash")
                                        }
                                    }
                                }
                            }
                        
                        if let tapSymbol = message.tapback, !isSelectionMode {
                            Image(systemName: tapSymbol)
                                .font(.system(size: 11, weight: .bold))
                                .foregroundStyle(tapSymbol == "heart.fill" ? .pink : .white)
                                .frame(width: 22, height: 22)
                                .background(Color(hex: "#2196F3"), in: Circle())
                                .offset(x: message.isFromMe ? -8 : 8, y: -8)
                                .onTapGesture {
                                    onTapback(nil)
                                }
                        }
                    }
                    
                    if message.isFromMe && isLastSentMessage && !isSelectionMode {
                        let hasTail = !isNextSameSender
                        HStack(spacing: 4) {
                            Text(timeString)
                                .font(.system(size: 9.5, weight: .regular))
                            Text(message.isRead ? "已读" : "已送达")
                                .font(.system(size: 9.5, weight: .bold))
                                .bold()
                        }
                        .foregroundStyle(.secondary)
                        .padding(.trailing, hasTail ? 19 : 8)
                    }
                }
                
                if !message.isFromMe { Spacer(minLength: 80) }
            }
            .padding(.horizontal, 16)
            .contentShape(Rectangle())
            .onTapGesture {
                if isSelectionMode {
                    onToggleSelect()
                }
            }
        }
        .padding(.top, isPrevSameSender ? 1.5 : 2)
        .padding(.bottom, isNextSameSender ? 1.5 : 6)
    }
    
    @ViewBuilder
    private var bubbleContentBody: some View {
        let isInvisible = (message.sendEffect == "invisible") && !isInvisibleRevealed
        let hasTail = !isNextSameSender
        
        let receiveGray = colorScheme == .dark
        ? Color(UIColor.secondarySystemGroupedBackground)
        : Color(hex: "#E5E5EA")
        
        let defaultBubbleColor: Color = message.isFromMe
        ? (message.isSMS ? Color(hex: "#34C759") : Color(hex: "#007AFF"))
        : receiveGray
        
        let bubbleColor: Color = {
            if message.isFromMe {
                return customBubbleColor ?? defaultBubbleColor
            } else {
                return customPeerBubbleColor ?? receiveGray
            }
        }()
        
        let defaultTextColor: Color = message.isFromMe ? .white : .primary
        let textColor: Color = {
            if message.isFromMe {
                return customTextColor ?? defaultTextColor
            } else {
                return customPeerTextColor ?? defaultTextColor
            }
        }()
        
        VStack(alignment: .leading, spacing: 4) {
            if let imgID = message.imageID,
               let data = LocalImageStore.shared.load(id: imgID),
               let uiImg = ImageBitmapCache.shared.image(from: data) {
                Image(uiImage: uiImg)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: 280, maxHeight: 300)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            }
            
            if !message.text.isEmpty {
                Text(message.text)
                    .font(.system(size: fontSize))
                    .foregroundStyle(textColor)
                    .padding(.vertical, 9)
                    .padding(.horizontal, 12)
                    .frame(minWidth: 48)
                    .background(
                        CompositeBubbleBackground(
                            isFromMe: message.isFromMe,
                            hasTail: hasTail,
                            tintColor: bubbleColor
                        )
                    )
            }
        }
        .blur(radius: isInvisible ? 6 : 0)
        .onTapGesture {
            if isInvisible { onRevealInvisible() }
        }
    }
}

// MARK: - 原生 iMessage 对方正在输入气泡
struct NativeTypingIndicatorBubble: View {
    @Environment(\.colorScheme) private var colorScheme
    @State private var animate = false
    
    var body: some View {
        let bubbleFill = colorScheme == .dark
        ? Color(UIColor.secondarySystemGroupedBackground)
        : Color(hex: "#E5E5EA")
        let dotColor = colorScheme == .dark ? Color(white: 0.65) : Color(hex: "#8E8E93")
        
        ZStack(alignment: .bottomLeading) {
            Circle()
                .fill(bubbleFill)
                .frame(width: 6, height: 6)
                .offset(x: -6, y: 6)
            
            Circle()
                .fill(bubbleFill)
                .frame(width: 12, height: 12)
                .offset(x: -1, y: 1)
            
            Capsule()
                .fill(bubbleFill)
                .frame(width: 58, height: 36)
            
            HStack(spacing: 4) {
                ForEach(0..<3, id: \.self) { idx in
                    Circle()
                        .fill(dotColor)
                        .frame(width: 8.5, height: 8.5)
                        .opacity(animate ? 1.0 : 0.3)
                        .animation(
                            .easeInOut(duration: 0.55)
                            .repeatForever(autoreverses: true)
                            .delay(Double(idx) * 0.17),
                            value: animate
                        )
                }
            }
            .frame(width: 58, height: 36)
        }
        .padding(.leading, 4)
        .padding(.bottom, 6)
        .onAppear {
            animate = true
        }
    }
}

// MARK: - 联系人详情原生 Form Sheet
@MainActor
struct NativeContactDetailSheet: View {
    let conversation: IMConversation
    @Binding var avatarPhotoItem: PhotosPickerItem?
    
    @Binding var selectedSendSoundID: Int
    @Binding var selectedReceiveSoundID: Int
    @Binding var customBubbleColorHex: String
    @Binding var customTextColorHex: String
    @Binding var customPeerBubbleColorHex: String
    @Binding var customPeerTextColorHex: String
    @Binding var customSendButtonColorHex: String
    @Binding var bgImageID: String
    @Binding var chatFontSize: Double
    let onClearAll: () -> Void
    
    @ObservedObject var viewModel = MessagesViewModel.shared
    @Environment(\.dismiss) private var dismiss
    @State private var editingName: String = ""
    @State private var bgPhotoItem: PhotosPickerItem? = nil
    
    @State private var myBubbleColor: Color = Color(hex: "#007AFF")
    @State private var myTextColor: Color = .white
    @State private var peerBubbleColor: Color = Color(hex: "#E5E5EA")
    @State private var peerTextColor: Color = .primary
    @State private var sendButtonColor: Color = Color(hex: "#007AFF")
    
    @State private var showConfirmClearInSheet: Bool = false
    
    private let bubblePresets: [(name: String, hex: String)] = [
        ("经典蓝", "#007AFF"),
        ("信息绿", "#34C759"),
        ("霓虹紫", "#AF52DE"),
        ("活力橙", "#FF9500"),
        ("曜石黑", "#1C1C1E"),
        ("樱花粉", "#FF2D55"),
        ("原生灰", "#E5E5EA")
    ]
    
    private let textPresets: [(name: String, hex: String)] = [
        ("纯白", "#FFFFFF"),
        ("曜黑", "#000000"),
        ("荧光绿", "#30D158"),
        ("浅金黄", "#FFD60A"),
        ("深灰", "#3A3A3C")
    ]
    
    var body: some View {
        NavigationStack {
            Form {
                // 1. 头像区
                Section {
                    VStack(spacing: 8) {
                        PhotosPicker(selection: $avatarPhotoItem, matching: .images, photoLibrary: .shared()) {
                            NativeContactAvatarView(
                                name: conversation.name,
                                colorHex: conversation.avatarColorHex,
                                imageID: conversation.avatarImageID,
                                size: 72
                            )
                        }
                        .buttonStyle(.plain)
                        Text("轻点更换头像")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .listRowBackground(Color.clear)
                }
                
                // 2. 界面文字大小调节
                Section("气泡文字大小调节") {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("A").font(.system(size: 13, weight: .medium))
                            Slider(value: $chatFontSize, in: 13...24, step: 0.5)
                            Text("A").font(.system(size: 22, weight: .bold))
                        }
                        
                        HStack {
                            Text("当前字号: \(String(format: "%.1f", chatFontSize)) pt")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Spacer()
                            if chatFontSize != 16.5 {
                                Button("恢复默认 (16.5 pt)") {
                                    chatFontSize = 16.5
                                }
                                .font(.caption)
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }
                
                // 3. 聊天背景壁纸
                Section("聊天背景壁纸") {
                    PhotosPicker(selection: $bgPhotoItem, matching: .images, photoLibrary: .shared()) {
                        HStack {
                            Label("从相册选择壁纸", systemImage: "photo.fill")
                            Spacer()
                            if !bgImageID.isEmpty,
                               let data = LocalImageStore.shared.load(id: bgImageID),
                               let uiImg = ImageBitmapCache.shared.image(from: data) {
                                Image(uiImage: uiImg)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 32, height: 32)
                                    .clipShape(RoundedRectangle(cornerRadius: 6))
                            }
                        }
                    }
                    
                    if !bgImageID.isEmpty {
                        Button(role: .destructive) {
                            bgImageID = ""
                        } label: {
                            Label("恢复默认背景 (移除壁纸)", systemImage: "trash")
                        }
                    }
                }
                
                // 4. 我方气泡与文字颜色定制
                Section("我方气泡、文字与发送键颜色") {
                    ColorPicker("气泡颜色", selection: $myBubbleColor, supportsOpacity: false)
                        .onChange(of: myBubbleColor) { _, newColor in
                            customBubbleColorHex = newColor.toHexString()
                        }
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(bubblePresets, id: \.hex) { preset in
                                Button {
                                    myBubbleColor = Color(hex: preset.hex)
                                    customBubbleColorHex = preset.hex
                                } label: {
                                    Circle()
                                        .fill(Color(hex: preset.hex))
                                        .frame(width: 28, height: 28)
                                        .overlay {
                                            if customBubbleColorHex == preset.hex {
                                                Image(systemName: "checkmark")
                                                    .font(.system(size: 12, weight: .bold))
                                                    .foregroundStyle(.white)
                                            }
                                        }
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    
                    if !customBubbleColorHex.isEmpty {
                        Button("恢复默认我方气泡颜色") {
                            customBubbleColorHex = ""
                            myBubbleColor = Color(hex: "#007AFF")
                        }
                        .font(.footnote)
                    }
                    
                    ColorPicker("文字颜色", selection: $myTextColor, supportsOpacity: false)
                        .onChange(of: myTextColor) { _, newColor in
                            customTextColorHex = newColor.toHexString()
                        }
                    
                    if !customTextColorHex.isEmpty {
                        Button("恢复默认我方文字颜色 (白色)") {
                            customTextColorHex = ""
                            myTextColor = .white
                        }
                        .font(.footnote)
                    }
                    
                    ColorPicker("发送箭头按钮颜色", selection: $sendButtonColor, supportsOpacity: false)
                        .onChange(of: sendButtonColor) { _, newColor in
                            customSendButtonColorHex = newColor.toHexString()
                        }
                    
                    if !customSendButtonColorHex.isEmpty {
                        Button("恢复默认 (跟随我方气泡)") {
                            customSendButtonColorHex = ""
                            sendButtonColor = myBubbleColor
                        }
                        .font(.footnote)
                    }
                }
                
                // 5. 对方气泡与文字颜色定制
                Section("对方气泡与文字颜色") {
                    ColorPicker("对方气泡颜色", selection: $peerBubbleColor, supportsOpacity: false)
                        .onChange(of: peerBubbleColor) { _, newColor in
                            customPeerBubbleColorHex = newColor.toHexString()
                        }
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(bubblePresets, id: \.hex) { preset in
                                Button {
                                    peerBubbleColor = Color(hex: preset.hex)
                                    customPeerBubbleColorHex = preset.hex
                                } label: {
                                    Circle()
                                        .fill(Color(hex: preset.hex))
                                        .frame(width: 28, height: 28)
                                        .overlay {
                                            if customPeerBubbleColorHex == preset.hex {
                                                Image(systemName: "checkmark")
                                                    .font(.system(size: 12, weight: .bold))
                                                    .foregroundStyle(preset.hex == "#E5E5EA" ? .black : .white)
                                            }
                                        }
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    
                    if !customPeerBubbleColorHex.isEmpty {
                        Button("恢复默认对方气泡颜色 (原生灰)") {
                            customPeerBubbleColorHex = ""
                            peerBubbleColor = Color(hex: "#E5E5EA")
                        }
                        .font(.footnote)
                    }
                    
                    ColorPicker("对方文字颜色", selection: $peerTextColor, supportsOpacity: false)
                        .onChange(of: peerTextColor) { _, newColor in
                            customPeerTextColorHex = newColor.toHexString()
                        }
                    
                    if !customPeerTextColorHex.isEmpty {
                        Button("恢复默认对方文字颜色") {
                            customPeerTextColorHex = ""
                            peerTextColor = .primary
                        }
                        .font(.footnote)
                    }
                }
                
                // 6. 提示铃声音效定制
                Section("铃声音效 (轻点可试听)") {
                    Picker("我发消息时的提示音", selection: $selectedSendSoundID) {
                        ForEach(chatSendSoundOptions) { option in
                            Text(option.name).tag(option.id)
                        }
                    }
                    .onChange(of: selectedSendSoundID) { _, newSoundID in
                        if newSoundID != 0 {
                            let sound = newSoundID
                            DispatchQueue.global(qos: .userInteractive).async {
                                AudioServicesPlaySystemSound(SystemSoundID(sound))
                            }
                        }
                    }
                    
                    Picker("对方回复时的提示音", selection: $selectedReceiveSoundID) {
                        ForEach(chatReceiveSoundOptions) { option in
                            Text(option.name).tag(option.id)
                        }
                    }
                    .onChange(of: selectedReceiveSoundID) { _, newSoundID in
                        if newSoundID != 0 {
                            let sound = newSoundID
                            DispatchQueue.global(qos: .userInteractive).async {
                                AudioServicesPlaySystemSound(SystemSoundID(sound))
                            }
                        }
                    }
                }
                
                // 7. 联系人资料区
                Section("联系人资料") {
                    LabeledContent("备注昵称") {
                        TextField("昵称", text: $editingName)
                            .multilineTextAlignment(.trailing)
                    }
                    LabeledContent("iMessage 号码", value: conversation.peerID)
                    Button("拷贝号码") {
                        UIPasteboard.general.string = conversation.peerID
                    }
                }
                
                // 8. 聊天记录高级管理
                Section {
                    Button(role: .destructive) {
                        showConfirmClearInSheet = true
                    } label: {
                        HStack {
                            Spacer()
                            Text("清空该对话所有聊天记录")
                            Spacer()
                        }
                    }
                }
            }
            .navigationTitle("详情")
            .navigationBarTitleDisplayMode(.inline)
            .confirmationDialog("确定要清空该会话所有聊天记录吗？此操作无法撤销。", isPresented: $showConfirmClearInSheet, titleVisibility: .visible) {
                Button("清空所有信息", role: .destructive) {
                    onClearAll()
                    dismiss()
                }
                Button("取消", role: .cancel) {}
            }
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") {
                        let trimmed = editingName.trimmingCharacters(in: .whitespacesAndNewlines)
                        guard !trimmed.isEmpty,
                              let idx = viewModel.conversations.firstIndex(where: { $0.id == conversation.id }) else {
                            dismiss()
                            return
                        }
                        viewModel.conversations[idx].name = trimmed
                        viewModel.saveConversations()
                        dismiss()
                    }
                }
            }
            .onAppear {
                editingName = conversation.name
                if !customBubbleColorHex.isEmpty {
                    myBubbleColor = Color(hex: customBubbleColorHex)
                }
                if !customTextColorHex.isEmpty {
                    myTextColor = Color(hex: customTextColorHex)
                }
                if !customPeerBubbleColorHex.isEmpty {
                    peerBubbleColor = Color(hex: customPeerBubbleColorHex)
                }
                if !customPeerTextColorHex.isEmpty {
                    peerTextColor = Color(hex: customPeerTextColorHex)
                }
                if !customSendButtonColorHex.isEmpty {
                    sendButtonColor = Color(hex: customSendButtonColorHex)
                } else if !customBubbleColorHex.isEmpty {
                    sendButtonColor = Color(hex: customBubbleColorHex)
                }
            }
            .task(id: bgPhotoItem) {
                if let item = bgPhotoItem,
                   let data = try? await item.loadTransferable(type: Data.self) {
                    if let savedID = LocalImageStore.shared.save(data: data) {
                        bgImageID = savedID
                    }
                    bgPhotoItem = nil
                }
            }
        }
    }
}
