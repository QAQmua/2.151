// 📄 文件路径：信息/MessagesViewModel.swift
import SwiftUI
import UIKit

// MARK: - 单条信息模型
public struct IMMessageItem: Identifiable, Codable, Equatable {
    public var id: String = UUID().uuidString
    public var isFromMe: Bool
    public var text: String
    public var imageID: String? = nil           // 存储在 LocalImageStore 中的 ID
    public var timestamp: Date = Date()
    public var isRead: Bool = false
    public var isSMS: Bool = false              // true 显示绿色短信气泡，false 显示蓝色 iMessage 气泡
    public var replyToID: String? = nil
    public var replyPreview: String? = nil
    public var tapback: String? = nil           // "heart.fill", "hand.thumbsup.fill", "hand.thumbsdown.fill", "haha", "exclam", "question"
    public var sendEffect: String? = nil        // "slam", "loud", "gentle", "invisible"
}

// MARK: - 会话线程模型
public struct IMConversation: Identifiable, Codable, Equatable {
    public var id: String                       // 对方的 iMessage 号码或唯一标识
    public var peerID: String                   // 远端设备号 (用于异地互发)
    public var name: String
    public var subtitleRole: String             // 如 "iMessage · 异地实时直连" 或 "AI 伴聊"
    public var avatarColorHex: String
    public var avatarImageID: String? = nil
    public var isPinned: Bool = false
    public var isMuted: Bool = false
    public var isAIContact: Bool = false
    public var isSMSChannel: Bool = false
    public var unreadCount: Int = 0
    public var messages: [IMMessageItem] = []
    
    public var lastMessageText: String {
        guard let last = messages.last else { return "暂无消息" }
        if last.imageID != nil && last.text.isEmpty { return "[图片]" }
        return last.text
    }
    
    public var lastTimestamp: Date {
        messages.last?.timestamp ?? Date.distantPast
    }
}

// MARK: - 信息全局数据与业务中心
@MainActor
public final class MessagesViewModel: ObservableObject {
    public static let shared = MessagesViewModel()
    
    private let storageKey = "App_IOS27_Messages_Conversations_V2"
    private let myIDKey = "App_IOS27_Messages_MyDeviceID"
    private let myNameKey = "App_IOS27_Messages_MyDisplayName"
    
    @Published public var conversations: [IMConversation] = []
    @Published public var myDeviceID: String = "" {
        didSet {
            UserDefaults.standard.set(myDeviceID, forKey: myIDKey)
            MessagesNetworkEngine.shared.connect(myDeviceID: myDeviceID)
        }
    }
    @Published public var myDisplayName: String = "" {
        didSet { UserDefaults.standard.set(myDisplayName, forKey: myNameKey) }
    }
    
    // 记录哪些远端设备正在输入 [peerID: Bool]
    @Published public var peerTypingMap: [String: Bool] = [:]
    
    private init() {
        // 1. 初始化或读取本机专属 6 位 iMessage 号码
        if let savedID = UserDefaults.standard.string(forKey: myIDKey), !savedID.isEmpty {
            self.myDeviceID = savedID
        } else {
            let p1 = Int.random(in: 100...999)
            let p2 = Int.random(in: 100...999)
            let generated = "\(p1)-\(p2)"
            self.myDeviceID = generated
            UserDefaults.standard.set(generated, forKey: myIDKey)
        }
        
        self.myDisplayName = UserDefaults.standard.string(forKey: myNameKey) ?? "幼刀"
        
        // 2. 加载本地会话列表
        loadConversations()
        
        // 3. 绑定跨网实时接收监听
        MessagesNetworkEngine.shared.onReceivePacket = { [weak self] packet in
            self?.handleIncomingPacket(packet)
        }
        MessagesNetworkEngine.shared.connect(myDeviceID: self.myDeviceID)
    }
    
    // MARK: - 本地持久化
    public func saveConversations() {
        let snapshot = self.conversations
        Task.detached(priority: .utility) {
            if let data = try? JSONEncoder().encode(snapshot) {
                UserDefaults.standard.set(data, forKey: "App_IOS27_Messages_Conversations_V2")
            }
        }
    }
    
    private func loadConversations() {
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let decoded = try? JSONDecoder().decode([IMConversation].self, from: data),
           !decoded.isEmpty {
            self.conversations = decoded
        } else {
            // 默认预置原生质感会话
            self.conversations = [
                IMConversation(
                    id: "ai_kanna",
                    peerID: "AI-KANNA",
                    name: "康娜 (AI 伴聊)",
                    subtitleRole: "iMessage · 智能在线",
                    avatarColorHex: "#A39BAE",
                    isPinned: true,
                    isAIContact: true,
                    unreadCount: 1,
                    messages: [
                        IMMessageItem(isFromMe: false, text: "今天有没有好好吃饭呀？可以随时给我发消息，或者点击右上角新建信息输入朋友的号码跨设备互发哦 ✨", timestamp: Date().addingTimeInterval(-3600), isRead: true)
                    ]
                ),
                IMConversation(
                    id: "apple_official",
                    peerID: "APPLE-ID",
                    name: "Apple",
                    subtitleRole: "官方服务通知",
                    avatarColorHex: "#8E8E93",
                    isPinned: true,
                    isSMSChannel: true,
                    unreadCount: 0,
                    messages: [
                        IMMessageItem(isFromMe: false, text: "【Apple】您的 Apple ID 验证码为 892104。请勿将此验证码告知他人。", timestamp: Date().addingTimeInterval(-7200), isRead: true, isSMS: true)
                    ]
                ),
                IMConversation(
                    id: "china_unicom",
                    peerID: "10010",
                    name: "中国联通",
                    subtitleRole: "10010 · 短信",
                    avatarColorHex: "#34C759",
                    isPinned: false,
                    isSMSChannel: true,
                    unreadCount: 0,
                    messages: [
                        IMMessageItem(isFromMe: false, text: "尊敬的用户，您本月 5G 畅爽套餐剩余国内高速流量 42.8 GB，话费余额 128.50 元。", timestamp: Date().addingTimeInterval(-86400), isRead: true, isSMS: true)
                    ]
                )
            ]
            saveConversations()
        }
    }
    
    // MARK: - 新建或获取与某台设备的会话
    public func getOrCreateConversation(peerID: String, customName: String? = nil) -> String {
        let normalized = MessagesNetworkEngine.normalizeID(peerID)
        if let existingIdx = conversations.firstIndex(where: { MessagesNetworkEngine.normalizeID($0.peerID) == normalized }) {
            if let name = customName, !name.trimmingCharacters(in: .whitespaces).isEmpty {
                conversations[existingIdx].name = name
                saveConversations()
            }
            return conversations[existingIdx].id
        }
        
        let displayPeer = peerID.trimmingCharacters(in: .whitespacesAndNewlines)
        let finalName = (customName?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false) ? customName! : "设备 \(displayPeer)"
        let palette = ["#007AFF", "#5856D6", "#FF2D55", "#FF9500", "#8FA4B5", "#A39BAE"]
        let newConv = IMConversation(
            id: normalized,
            peerID: displayPeer,
            name: finalName,
            subtitleRole: "iMessage · 跨设备实时直连",
            avatarColorHex: palette.randomElement() ?? "#007AFF",
            isPinned: false,
            isAIContact: false,
            isSMSChannel: false,
            unreadCount: 0,
            messages: []
        )
        conversations.insert(newConv, at: 0)
        saveConversations()
        return newConv.id
    }
    
    // MARK: - 发送文本/图片消息
    public func sendMessage(
        in conversationID: String,
        text: String,
        imageData: Data? = nil,
        replyTo: IMMessageItem? = nil,
        effect: String? = nil
    ) {
        guard let idx = conversations.firstIndex(where: { $0.id == conversationID }) else { return }
        
        var savedImageID: String? = nil
        var compressedBase64: String? = nil
        
        if let rawData = imageData {
            savedImageID = LocalImageStore.shared.save(data: rawData)
            // 压缩图片以便跨网毫秒级传输
            if let uiImg = UIImage(data: rawData),
               let compressed = Self.compressImageForTransfer(uiImg, maxDimension: 520, quality: 0.55) {
                compressedBase64 = compressed.base64EncodedString()
            }
        }
        
        let msgID = UUID().uuidString
        let newMessage = IMMessageItem(
            id: msgID,
            isFromMe: true,
            text: text,
            imageID: savedImageID,
            timestamp: Date(),
            isRead: false,
            isSMS: conversations[idx].isSMSChannel,
            replyToID: replyTo?.id,
            replyPreview: replyTo?.text.isEmpty == false ? replyTo?.text : (replyTo?.imageID != nil ? "[图片]" : nil),
            tapback: nil,
            sendEffect: effect
        )
        
        conversations[idx].messages.append(newMessage)
        let targetConv = conversations[idx]
        
        // 将最新活跃的会话移到前面
        if idx > 0 {
            let moved = conversations.remove(at: idx)
            conversations.insert(moved, at: 0)
        }
        saveConversations()
        
        // 1. 如果是 AI 联系人，调用设置里的 AIApiManager 回复
        if targetConv.isAIContact {
            triggerAIReply(for: targetConv.id, userText: text)
            return
        }
        
        // 2. 如果是真实跨设备会话，通过全球信令引擎实时发送给对方手机
        if !targetConv.isSMSChannel {
            let packet = IMNetworkPacket(
                id: msgID,
                packetType: compressedBase64 != nil ? .image : .text,
                senderID: myDeviceID,
                senderName: myDisplayName,
                senderAvatarBase64: nil,
                targetID: targetConv.peerID,
                textContent: text,
                imageBase64: compressedBase64,
                replyToID: newMessage.replyToID,
                replyPreview: newMessage.replyPreview,
                tapbackSymbol: nil,
                sendEffect: effect,
                isTyping: false,
                timestamp: Date().timeIntervalSince1970
            )
            MessagesNetworkEngine.shared.sendPacket(packet)
        }
    }
    
    // MARK: - 发送 Tapback 气泡回应 (❤️ 👍 👎 😂 ‼️ ❓)
    public func sendTapback(in conversationID: String, messageID: String, symbol: String?) {
        guard let cIdx = conversations.firstIndex(where: { $0.id == conversationID }),
              let mIdx = conversations[cIdx].messages.firstIndex(where: { $0.id == messageID }) else { return }
        
        conversations[cIdx].messages[mIdx].tapback = symbol
        let peerID = conversations[cIdx].peerID
        saveConversations()
        
        let packet = IMNetworkPacket(
            id: messageID,
            packetType: .tapback,
            senderID: myDeviceID,
            senderName: myDisplayName,
            senderAvatarBase64: nil,
            targetID: peerID,
            textContent: nil,
            imageBase64: nil,
            replyToID: nil,
            replyPreview: nil,
            tapbackSymbol: symbol,
            sendEffect: nil,
            isTyping: nil,
            timestamp: Date().timeIntervalSince1970
        )
        MessagesNetworkEngine.shared.sendPacket(packet)
    }
    
    // MARK: - 发送「正在输入...」与「已读回执」
    public func sendTypingStatus(to peerID: String, isTyping: Bool) {
        let packet = IMNetworkPacket(
            id: UUID().uuidString,
            packetType: .typing,
            senderID: myDeviceID,
            senderName: myDisplayName,
            senderAvatarBase64: nil,
            targetID: peerID,
            textContent: nil,
            imageBase64: nil,
            replyToID: nil,
            replyPreview: nil,
            tapbackSymbol: nil,
            sendEffect: nil,
            isTyping: isTyping,
            timestamp: Date().timeIntervalSince1970
        )
        MessagesNetworkEngine.shared.sendPacket(packet)
    }
    
    public func markConversationAsRead(_ conversationID: String) {
        guard let idx = conversations.firstIndex(where: { $0.id == conversationID }) else { return }
        if conversations[idx].unreadCount > 0 {
            conversations[idx].unreadCount = 0
            saveConversations()
        }
        
        let peerID = conversations[idx].peerID
        guard !conversations[idx].isAIContact && !conversations[idx].isSMSChannel else { return }
        
        let packet = IMNetworkPacket(
            id: UUID().uuidString,
            packetType: .readReceipt,
            senderID: myDeviceID,
            senderName: myDisplayName,
            senderAvatarBase64: nil,
            targetID: peerID,
            textContent: nil,
            imageBase64: nil,
            replyToID: nil,
            replyPreview: nil,
            tapbackSymbol: nil,
            sendEffect: nil,
            isTyping: nil,
            timestamp: Date().timeIntervalSince1970
        )
        MessagesNetworkEngine.shared.sendPacket(packet)
    }
    
    // MARK: - 处理从另一台 iOS 设备收到的实时数据包
    private func handleIncomingPacket(_ packet: IMNetworkPacket) {
        let senderNormalized = MessagesNetworkEngine.normalizeID(packet.senderID)
        // 忽略自己发给自己的回环（除非刻意测试本机自发自收）
        if senderNormalized == MessagesNetworkEngine.normalizeID(myDeviceID) && packet.senderName == myDisplayName {
            // 允许单机自测：如果用户在新建里填了自己的号码，也能收到体验
        }
        
        switch packet.packetType {
        case .typing:
            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                peerTypingMap[senderNormalized] = packet.isTyping ?? false
            }
            
        case .readReceipt:
            if let cIdx = conversations.firstIndex(where: { MessagesNetworkEngine.normalizeID($0.peerID) == senderNormalized }) {
                for i in 0..<conversations[cIdx].messages.count {
                    conversations[cIdx].messages[i].isRead = true
                }
                saveConversations()
            }
            
        case .tapback:
            if let cIdx = conversations.firstIndex(where: { MessagesNetworkEngine.normalizeID($0.peerID) == senderNormalized }),
               let mIdx = conversations[cIdx].messages.firstIndex(where: { $0.id == packet.id }) {
                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                withAnimation(.spring(response: 0.35, dampingFraction: 0.65)) {
                    conversations[cIdx].messages[mIdx].tapback = packet.tapbackSymbol
                }
                saveConversations()
            }
            
        case .text, .image:
            peerTypingMap[senderNormalized] = false
            let convID = getOrCreateConversation(peerID: packet.senderID, customName: packet.senderName)
            guard let cIdx = conversations.firstIndex(where: { $0.id == convID }) else { return }
            
            // 防止重复接收相同 ID 的消息
            guard !conversations[cIdx].messages.contains(where: { $0.id == packet.id }) else { return }
            
            var savedImgID: String? = nil
            if let base64 = packet.imageBase64, let imgData = Data(base64Encoded: base64) {
                savedImgID = LocalImageStore.shared.save(data: imgData)
            }
            
            let incomingMsg = IMMessageItem(
                id: packet.id,
                isFromMe: false,
                text: packet.textContent ?? "",
                imageID: savedImgID,
                timestamp: Date(timeIntervalSince1970: packet.timestamp),
                isRead: true,
                isSMS: false,
                replyToID: packet.replyToID,
                replyPreview: packet.replyPreview,
                tapback: nil,
                sendEffect: packet.sendEffect
            )
            
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            withAnimation(.spring(response: 0.35, dampingFraction: 0.82)) {
                conversations[cIdx].name = packet.senderName.isEmpty ? conversations[cIdx].name : packet.senderName
                conversations[cIdx].messages.append(incomingMsg)
                conversations[cIdx].unreadCount += 1
                
                // 置顶最新收到消息的会话
                let updated = conversations.remove(at: cIdx)
                conversations.insert(updated, at: 0)
            }
            saveConversations()
            
            // 🌟 联动桌面 2x2 消息卡片小组件！实时显示朋友发来的最新消息
            ChatListWidgetManager.shared.name1 = packet.senderName
            ChatListWidgetManager.shared.message1 = incomingMsg.text.isEmpty ? "[图片]" : incomingMsg.text
            ChatListWidgetManager.shared.status1 = "未读"
        }
    }
    
    // MARK: - AI 智能伴聊（对接您项目中的 AIApiManager）
    private func triggerAIReply(for conversationID: String, userText: String) {
        let peerNorm = "ai-kanna"
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 600_000_000)
            withAnimation { peerTypingMap[peerNorm] = true }
            
            // 标记我发出的消息为“已读”
            if let cIdx = conversations.firstIndex(where: { $0.id == conversationID }) {
                for i in 0..<conversations[cIdx].messages.count {
                    conversations[cIdx].messages[i].isRead = true
                }
            }
            
            var replyString = "收到啦！我已经记住你说的话啦 ✨（如果你在「设置 -> API 反代配置」里填入 API Key，我就能用满血大模型陪你聊天哦！）"
            
            let apiMgr = AIApiManager.shared
            let token = apiMgr.apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
            if !token.isEmpty, let url = URL(string: "\(apiMgr.cleanBaseURL)/chat/completions") {
                var req = URLRequest(url: url)
                req.httpMethod = "POST"
                req.timeoutInterval = 15
                req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
                req.setValue("application/json", forHTTPHeaderField: "Content-Type")
                
                let bodyDict: [String: Any] = [
                    "model": apiMgr.selectedModel,
                    "temperature": apiMgr.temperature,
                    "messages": [
                        ["role": "system", "content": "你是康娜，一个呆萌可爱的女孩，说话简短温柔，像在用苹果 iMessage 气泡和朋友发短信一样自然。"],
                        ["role": "user", "content": userText]
                    ]
                ]
                req.httpBody = try? JSONSerialization.data(withJSONObject: bodyDict)
                
                if let (data, resp) = try? await URLSession.shared.data(for: req),
                   let http = resp as? HTTPURLResponse, http.statusCode == 200,
                   let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let choices = json["choices"] as? [[String: Any]],
                   let msg = choices.first?["message"] as? [String: Any],
                   let content = msg["content"] as? String {
                    replyString = content.trimmingCharacters(in: .whitespacesAndNewlines)
                }
            } else {
                try? await Task.sleep(nanoseconds: 1_200_000_000)
            }
            
            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                peerTypingMap[peerNorm] = false
                if let idx = conversations.firstIndex(where: { $0.id == conversationID }) {
                    let aiMsg = IMMessageItem(
                        isFromMe: false,
                        text: replyString,
                        timestamp: Date(),
                        isRead: true
                    )
                    conversations[idx].messages.append(aiMsg)
                    saveConversations()
                }
            }
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        }
    }
    
    // 图片等比压缩工具
    private static func compressImageForTransfer(_ image: UIImage, maxDimension: CGFloat, quality: CGFloat) -> Data? {
        let size = image.size
        let aspectRatio = size.width / max(size.height, 1)
        var newSize = size
        if max(size.width, size.height) > maxDimension {
            if aspectRatio > 1 {
                newSize = CGSize(width: maxDimension, height: maxDimension / aspectRatio)
            } else {
                newSize = CGSize(width: maxDimension * aspectRatio, height: maxDimension)
            }
        }
        let renderer = UIGraphicsImageRenderer(size: newSize)
        let resized = renderer.image { _ in
            image.draw(in: CGRect(origin: .zero, size: newSize))
        }
        return resized.jpegData(compressionQuality: quality)
    }
}
